boats = "boats"

# local version
# url_root = "http://127.0.0.1:8080"
# deployed version
url_root = "https://hw5-paceym.wl.r.appspot.com"

